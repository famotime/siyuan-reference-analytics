"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const a=require("./index-0ohsPWR0.cjs"),I=/siyuan:\/\/blocks\/([^?\s<>"')\]#]+)/gi,k=/\(\(\s*([^)\s"']+)(?:\s+(?:"[^"]*"|'[^']*'))?\s*\)\)/g;function g(t){const o=new Set;for(const c of t)for(const e of E(c.markdown??""))o.add(e.targetBlockId);return[...o]}function f(t){const o=new Map(t.targetRows.map(e=>[e.id,e.rootId||e.id])),c=[];for(const e of t.sourceRows){const r=e.rootId||e.id;E(e.markdown??"").forEach((d,n)=>{const i=o.get(d.targetBlockId);!i||r===i||c.push({id:`markdown-ref:${e.id}:${d.targetBlockId}:${n}`,sourceBlockId:e.id,sourceDocumentId:r,targetBlockId:d.targetBlockId,targetDocumentId:i,content:d.content,sourceUpdated:e.updated??""})})}return c}function E(t){return[...S(t),...L(t)]}function S(t){return[...t.matchAll(I)].map(o=>({targetBlockId:o[1],content:o[0]}))}function L(t){return[...t.matchAll(k)].map(o=>({targetBlockId:o[1],content:o[0]}))}const u=2e5,p=`
  SELECT
    id,
    box,
    path,
    hpath,
    CASE
      WHEN COALESCE(TRIM(content), '') <> '' THEN content
      WHEN COALESCE(TRIM(name), '') <> '' THEN name
      ELSE hpath
    END AS title,
    tag,
    created,
    updated
  FROM blocks
  WHERE type = 'd'
  ORDER BY updated DESC
  LIMIT ${u}
`,R=`
  SELECT
    r.id AS id,
    r.block_id AS sourceBlockId,
    r.root_id AS sourceDocumentId,
    r.def_block_id AS targetBlockId,
    r.def_block_root_id AS targetDocumentId,
    COALESCE(r.content, src_block.content, '') AS content,
    COALESCE(src_block.updated, src_doc.updated, '') AS sourceUpdated
  FROM refs r
  LEFT JOIN blocks src_block ON src_block.id = r.block_id
  LEFT JOIN blocks src_doc ON src_doc.id = r.root_id
  WHERE r.type = 'ref_id'
    AND r.root_id <> r.def_block_root_id
  ORDER BY sourceUpdated DESC
  LIMIT ${u}
`,_=`
  SELECT
    id,
    COALESCE(NULLIF(root_id, ''), id) AS rootId,
    markdown,
    updated
  FROM blocks
  WHERE (
      COALESCE(markdown, '') LIKE '%siyuan://blocks/%'
      OR COALESCE(markdown, '') LIKE '%((%'
    )
  LIMIT ${u}
`;async function m(){const[t,o,c,e]=await Promise.all([a.sql(p),a.sql(R),a.sql(_),a.lsNotebooks()]),r=g(c??[]),s=await T(r),d=f({sourceRows:c??[],targetRows:s});return{documents:(t??[]).map(n=>({id:n.id,box:n.box,path:n.path,hpath:n.hpath,title:n.title,tags:A(n.tag),created:n.created,updated:n.updated})),references:O((o??[]).map(n=>({id:n.id,sourceBlockId:n.sourceBlockId,sourceDocumentId:n.sourceDocumentId,targetBlockId:n.targetBlockId,targetDocumentId:n.targetDocumentId,content:n.content??"",sourceUpdated:n.sourceUpdated??""})),d),notebooks:((e==null?void 0:e.notebooks)??[]).map(n=>({id:n.id,name:n.name})),fetchedAt:new Date().toISOString()}}function A(t){return t?t.split(/[,\s#]+/).map(o=>o.trim()).filter(Boolean):[]}async function T(t){if(t.length===0)return[];const o=[];for(const c of C(t,200)){const e=await a.sql(`
      SELECT id, COALESCE(NULLIF(root_id, ''), id) AS rootId
      FROM blocks
      WHERE id IN (${c.map(h).join(", ")})
      LIMIT ${c.length}
    `);o.push(...e??[])}return o}function C(t,o){const c=[];for(let e=0;e<t.length;e+=o)c.push(t.slice(e,e+o));return c}function h(t){return`'${t.replaceAll("'","''")}'`}function O(t,o){const c=[...t],e=new Set(t.map(l));for(const r of o){const s=l(r);e.has(s)||(e.add(s),c.push(r))}return c}function l(t){return[t.sourceDocumentId,t.sourceBlockId,t.targetDocumentId,t.targetBlockId].join("::")}exports.loadAnalyticsSnapshot=m;
