"use strict";require("siyuan");const e=require("./index-0ohsPWR0.cjs");module.exports=e.ReferenceAnalyticsPlugin;
